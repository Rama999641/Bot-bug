const global = {
    owner: [6142885267], // ganti jadi id mu
    botToken: "7936619334:AAGhGMUtdqV25Kw-D_i_y4DGEZbN74Ci_s0", //isi make token bot mu
}

module.exports = global;